import { useState } from "react";
import { Button } from "../components/ui/button";
import { Card, CardContent } from "../components/ui/card";
import { motion } from "framer-motion";

const products = [
  { name: "Producto 1", image: "/images/producto1.jpg", price: 25000 },
  { name: "Producto 2", image: "/images/producto2.jpg", price: 40000 },
  { name: "Producto 3", image: "/images/producto3.jpg", price: 38000 },
];

export default function Home() {
  const [cart, setCart] = useState([]);
  const addToCart = (product) => setCart([...cart, product]);
  const total = cart.reduce((acc, item) => acc + item.price, 0);

  return (
    <main className="min-h-screen bg-black text-white font-sans">
      <header className="text-center py-10">
        <motion.h1 initial={{ opacity: 0, y: -30 }} animate={{ opacity: 1, y: 0 }} className="text-5xl font-serif tracking-widest">
          TWO<span className="text-gray-400">C</span> LUX
        </motion.h1>
        <p className="text-gray-400 mt-2">Joyería de acero inoxidable</p>
      </header>
      <section className="grid md:grid-cols-3 gap-6 px-6 py-6">
        {products.map((product, index) => (
          <Card key={index} className="bg-zinc-900 border border-zinc-700">
            <CardContent className="p-4">
              <img src={product.image} alt={product.name} className="rounded-xl mb-4 w-full h-56 object-cover" />
              <h2 className="text-xl font-bold mb-2">{product.name}</h2>
              <p className="text-gray-300 mb-2">${product.price}</p>
              <Button onClick={() => addToCart(product)} className="w-full">Añadir al carrito</Button>
            </CardContent>
          </Card>
        ))}
      </section>
      <section className="p-6 text-center">
        <h3 className="text-2xl font-semibold mb-4">Carrito</h3>
        {cart.length === 0 ? <p className="text-gray-400">Tu carrito está vacío.</p> : (
          <>
            <ul className="text-gray-300 mb-4">{cart.map((item, i) => <li key={i}>• {item.name} - ${item.price}</li>)}</ul>
            <p className="text-lg font-semibold mb-4">Total: ${total}</p>
            <Button className="bg-green-600 text-white" onClick={() => window.open(`https://wa.me/573127863965?text=${encodeURIComponent(`Hola, quiero comprar:\n${cart.map(item => `- ${item.name}: $${item.price}`).join("\n")}\nTotal: $${total}`)}`, "_blank")}>
              Finalizar compra por WhatsApp
            </Button>
          </>
        )}
      </section>
      <footer className="p-6 border-t border-gray-700 text-center text-gray-400">
        <h4 className="text-xl mb-2">Sobre nosotros</h4>
        <p>En TwoC Lux creamos joyas de acero inoxidable con estilo, elegancia y durabilidad. Cada pieza está hecha para destacar.</p>
      </footer>
    </main>
  );
}
